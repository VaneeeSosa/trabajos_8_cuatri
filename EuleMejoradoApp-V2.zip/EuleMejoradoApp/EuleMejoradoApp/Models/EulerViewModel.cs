﻿using System.ComponentModel.DataAnnotations;

namespace EuleMejoradoApp.Models
{
    public class EulerInputModel
    {
        [Required(ErrorMessage = "El valor inicial de X es requerido.")]
        [Display(Name = "Valor inicial de x (X0)")]
        public double X0 { get; set; }

        [Required(ErrorMessage = "El valor inicial de Y es requerido.")]
        [Display(Name = "Valor inicial de y (Y0)")]
        public double Y0 { get; set; }

        [Required(ErrorMessage = "El tamaño del paso (h) es requerido.")]
        [Range(0.0000001, double.MaxValue, ErrorMessage = "El valor de h debe ser mayor que 0.")]
        [Display(Name = "Tamaño del paso (h)")]
        public double H { get; set; }

        [Required(ErrorMessage = "El número de pasos es requerido.")]
        [Range(1, int.MaxValue, ErrorMessage = "El número de pasos debe ser al menos 1.")]
        [Display(Name = "Número de pasos")]
        public int Steps { get; set; }

        [Required(ErrorMessage = "La ecuación es requerida.")]
        [Display(Name = "Ecuación (en función de x e y)")]
        public string Ecuacion { get; set; }
    }

    public class EulerResult
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double YReal { get; set; }
        public double Error { get; set; }
    }
}

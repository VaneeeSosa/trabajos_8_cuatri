﻿using EuleMejoradoApp.Models;
using Microsoft.AspNetCore.Mvc;
using NCalc;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace EuleMejoradoApp.Controllers
{
    public class EulerController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View(new EulerInputModel());
        }

        [HttpPost]
        public ActionResult Index(EulerInputModel model)
        {
            // Preprocesar la ecuación para quitar el prefijo "f(x)=" si existe.
            if (!string.IsNullOrEmpty(model.Ecuacion))
            {
                model.Ecuacion = model.Ecuacion.Trim();
                if (model.Ecuacion.StartsWith("f(x)="))
                {
                    model.Ecuacion = model.Ecuacion.Substring(5).Trim();
                }
                // Limpiar errores en ModelState si se ingresó un valor (para los espacios y demas).
                if (ModelState.ContainsKey("Ecuacion") && !string.IsNullOrWhiteSpace(model.Ecuacion))
                {
                    ModelState["Ecuacion"].Errors.Clear();
                }
            }

            if (ModelState.IsValid)
            {
                var results = new List<EulerResult>();

                double x = model.X0;
                double y = model.Y0;
                // Calcula yReal según la fórmula: yReal = e^(0.2) + 0.2 * x^2
                double yRealInit = GetExactSolution(x);
                results.Add(new EulerResult
                {
                    X = x,
                    Y = y,
                    YReal = yRealInit,
                    Error = yRealInit - y
                });

                // este if itera por cada "Numero de pasos" ingresado
                for (int i = 0; i < model.Steps; i++)
                {
                    // Método de Euler Mejorado (Heun)

                    // Se evalúa la función f(x,y) usando la ecuación ingresada (después de preprocesarla)
                    //en el punto actual 
                    double fxy = f(model.Ecuacion, x, y);

                    //Se calcula un valor provisional de y usando el paso h y la pendiente f(x, y).
                    //Esta es la primera aproximación
                    double yPredict = y + model.H * fxy;

                    //se utiliza para mejorar la aproximación.
                    double fPredict = f(model.Ecuacion, x + model.H, yPredict);

                    //Se calcula el nuevo valor de y (yn+1) como la suma del valor actual "y"
                    //y el promedio ponderado de las pendientes (la original y la predicha) multiplicado por el paso h.
                    double yNext = y + model.H / 2 * (fxy + fPredict);


                    //Se incrementa "x" en "h" y se actualiza "y" con el nuevo valor calculado.
                    //es importante para continuar con la iteracion
                    x += model.H;
                    y = yNext;

                    // GetExactSolution es un metodo que contiene la formula para la yreal
                    double yReal = GetExactSolution(x);
                    double error = yReal - y;

                    // se agregan los resultados a la tabla
                    results.Add(new EulerResult
                    {
                        X = x,
                        Y = y,
                        YReal = yReal,
                        Error = error
                    });
                }

                ViewBag.Results = results;
            }
            return View(model);
        }

        // Evalúa la función f(x,y) a partir de la ecuación ingresada usando NCalc.
        private double f(string ecuacion, double x, double y)
        {
            try
            {
                // aqui se reemplaza "√" por "Sqrt" para que NCalc reconozca la función de raíz cuadrada.
                string expressionStr = ecuacion.Replace("√", "Sqrt");
                expressionStr = PreprocesarEcuacion(expressionStr);

                var expr = new Expression(expressionStr);
                expr.Parameters["x"] = x;
                expr.Parameters["y"] = y;

                var result = expr.Evaluate();
                return Convert.ToDouble(result);
            }
            catch
            {
                return double.NaN;
            }
        }

        // Preprocesa la cadena para insertar multiplicaciones implícitas (en caso de que vengan asi "f(x)=0.4xy").
        private string PreprocesarEcuacion(string ecuacion)
        {
            ecuacion = ecuacion.Replace(" ", "");

            // Inserta multiplicación entre número y letra o paréntesis
            ecuacion = Regex.Replace(ecuacion, @"(\d)([a-zA-Z(])", "$1*$2");

            // Inserta multiplicación entre letra y paréntesis
            ecuacion = Regex.Replace(ecuacion, @"([a-zA-Z])\(", "$1*(");

            // Inserta multiplicación entre paréntesis y letra
            ecuacion = Regex.Replace(ecuacion, @"\)([a-zA-Z])", ")*$1");

            // Inserta multiplicación entre letras (p. ej., "xy" se convierte en "x*y")
            ecuacion = Regex.Replace(ecuacion, @"([a-zA-Z])([a-zA-Z])", "$1*$2");

            return ecuacion;
        }

        // Calcula yReal usando la fórmula: yReal = e^(0.2) + 0.2 * x^2
        private double GetExactSolution(double x)
        {
            return Math.Exp(0.2) + 0.2 * Math.Pow(x, 2);
        }
    }
}

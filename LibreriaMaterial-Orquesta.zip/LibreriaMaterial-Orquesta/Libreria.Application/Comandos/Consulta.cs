﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Libreria.Application.DTOs;
using Libreria.Domain.Interfaces;
using AutoMapper;
using MediatR;

namespace Libreria.Application.Comandos
{
    public class Consulta
    {

        public class Ejecuta : IRequest<List<LibreriaMaterialDto>>
        {
            public Ejecuta()
            {

            }
        }
        public class Manejador : IRequestHandler<Ejecuta, List<LibreriaMaterialDto>>
        {
            private readonly ILibreriaMaterialRepositorio _repository;
            private readonly IMapper _mapper;

            public Manejador(ILibreriaMaterialRepositorio repository, IMapper mapper)
            {
                _repository = repository;
                _mapper = mapper;
            }

            public async Task<List<LibreriaMaterialDto>> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var libros = await _repository.GetAllAsync();
                return _mapper.Map<List<LibreriaMaterialDto>>(libros);
            }
        }
    }
}

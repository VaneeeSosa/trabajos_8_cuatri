﻿using Libreria.Domain.Interfaces;
using Libreria.Domain.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using FluentValidation;

namespace Libreria.Application.Comandos
{
    public class Nuevo
    {
        public class Ejecuta : IRequest
        {
            public string Titulo { get; set; }
            public DateTime? FechaPublicacion { get; set; }
            public string AutorLibro { get; set; }
        }

        public class EjecutaValidacion : AbstractValidator<Ejecuta>
        {
            public EjecutaValidacion()
            {
                RuleFor(x => x.Titulo).NotEmpty();

                RuleFor(x => x.FechaPublicacion).NotEmpty();

                RuleFor(x => x.AutorLibro).NotEmpty();
            }
        }

        public class Manejador : IRequestHandler<Ejecuta>
        {
            private readonly ILibreriaMaterialRepositorio _repository;

            public Manejador(ILibreriaMaterialRepositorio repository)
            {
                _repository = repository;
            }

            public async Task<Unit> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var libro = new LibreriaMaterial
                {
                    Titulo = request.Titulo,
                    FechaPublicacion = request.FechaPublicacion, 
                    AutorLibro = request.AutorLibro
                };

                await _repository.AddAsync(libro);

                return Unit.Value;
            }
        }
    }
}

﻿using Libreria.Domain.Modelo;
using Libreria.Application.DTOs;
using Libreria.Domain.Interfaces;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.Comandos
{
    public class ConsultaFiltro
    {
        public class LibroUnico : IRequest<LibreriaMaterialDto>
        {
            public int LibroId { get; set; }
        }

        public class Manejador : IRequestHandler<LibroUnico, LibreriaMaterialDto>
        {
            private readonly ILibreriaMaterialRepositorio _repository;
            private readonly IMapper _mapper;
            public Manejador(ILibreriaMaterialRepositorio repositorio, IMapper mapper)
            {
                _repository = repositorio;
                _mapper = mapper;
            }
            public async Task<LibreriaMaterialDto> Handle(LibroUnico request, CancellationToken cancellationToken)
            {
                var libro = await _repository.GetByIdAsync(request.LibroId);

                if (libro == null)
                {
                    throw new Exception("No se encontró el libro");
                }

                return _mapper.Map<LibreriaMaterialDto>(libro);
            }
        }
    }
}

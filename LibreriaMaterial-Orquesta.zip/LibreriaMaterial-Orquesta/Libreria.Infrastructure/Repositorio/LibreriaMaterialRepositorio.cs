﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Libreria.Domain.Interfaces;
using Libreria.Domain.Modelo;
using Libreria.Infrastructure.Persistencia;

namespace Libreria.Infrastructure.Repositorio
{
    public class LibreriaMaterialRepositorio : ILibreriaMaterialRepositorio
    {
        private readonly ContextoLibreria _context;

        public LibreriaMaterialRepositorio(ContextoLibreria context)
        {
            _context = context;
        }

        public async Task<List<LibreriaMaterial>> GetAllAsync()
        {
            return await _context.LibreriaMaterial.ToListAsync();
        }

        public async Task<LibreriaMaterial> GetByIdAsync(int id)
        {
            return await _context.LibreriaMaterial.FindAsync(id);
        }

        public async Task AddAsync(LibreriaMaterial material)
        {
            _context.LibreriaMaterial.Add(material);
            await _context.SaveChangesAsync();
        }
    }
}

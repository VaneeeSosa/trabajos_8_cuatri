﻿using Libreria.Domain.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Domain.Interfaces
{
    public interface ILibreriaMaterialRepositorio
    {
        Task<List<LibreriaMaterial>> GetAllAsync();
        Task<LibreriaMaterial> GetByIdAsync(int id);
        Task AddAsync(LibreriaMaterial material);
    }
}

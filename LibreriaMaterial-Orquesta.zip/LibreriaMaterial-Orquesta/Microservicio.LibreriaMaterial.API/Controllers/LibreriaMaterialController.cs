﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Libreria.Application.Comandos;
using Libreria.Application.DTOs;
using MediatR;

namespace Microservicio.LibreriaMaterial.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class LibreriaMaterialController : ControllerBase
    {

        private readonly IMediator _mediator;

        public LibreriaMaterialController(IMediator mediator)
        {
            _mediator = mediator;
        }


        // POST api/<ValuesController>
        [HttpPost]
        public async Task<ActionResult<Unit>> crear(Nuevo.Ejecuta data)
        {
            return await _mediator.Send(data);
        }

        [HttpGet]
        public async Task<ActionResult<List<LibreriaMaterialDto>>> GetLibros()
        {
            return await _mediator.Send(new Consulta.Ejecuta());
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<LibreriaMaterialDto>> GetLibroUnico(int id)
        {
            return await _mediator.Send(new ConsultaFiltro.LibroUnico
            {
                LibroId = id
            });
        }
    }
}

﻿using Libreria.Infrastructure.Persistencia;
using Libreria.Application.Comandos;
using Libreria.Domain.Interfaces;
using Libreria.Infrastructure.Repositorio;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using FluentValidation.AspNetCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Infrastructure.Extensiones
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddCustomServices(this IServiceCollection services,
           IConfiguration configuration)
        {
            services.AddControllers().AddFluentValidation(cfg => cfg.RegisterValidatorsFromAssemblyContaining<Nuevo>());

            services.AddDbContext<ContextoLibreria>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));
            services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigns",

                    builder =>
                    {
                        builder.WithOrigins("http://example.com", "https://another-example.com", "*")
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                    });

                options.AddPolicy("AllowAll",
                    builder =>
                    {
                        builder.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                    });
            });
            // En ServiceCollectionExtensions
            services.AddScoped<ILibreriaMaterialRepositorio, LibreriaMaterialRepositorio>();
            services.AddMediatR(typeof(Nuevo.Manejador).Assembly);
            services.AddAutoMapper(typeof(Consulta.Manejador));
            services.AddScoped<ILibreriaMaterialRepositorio, LibreriaMaterialRepositorio>();
            services.AddScoped<SagaCoordinator>();

            return services;

        }
    }
}

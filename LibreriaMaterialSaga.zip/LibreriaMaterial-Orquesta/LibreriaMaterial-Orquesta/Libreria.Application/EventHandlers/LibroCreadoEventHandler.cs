﻿using Libreria.Application.Saga;
using Libreria.Domain.Interfaces;
using Libreria.Domain.Modelo;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.EventHandlers
{
    public class LibroCreadoEventHandler : INotificationHandler<LibroCreadoEvent>
    {
        private readonly ILibreriaMaterialRepositorio _repository;

        public LibroCreadoEventHandler(ILibreriaMaterialRepositorio repository)
        {
            _repository = repository;
        }
        // notifica a otros servicios para guardarlo en la bd el nuevo  libro
        public async Task Handle(LibroCreadoEvent notification, CancellationToken cancellationToken)
        {
            var libro = new LibreriaMaterial
            {
                Titulo = notification.Titulo,
                FechaPublicacion = notification.FechaPublicacion,
                AutorLibro = notification.AutorLibro
            };

            await _repository.AddAsync(libro);
        }
    }
}

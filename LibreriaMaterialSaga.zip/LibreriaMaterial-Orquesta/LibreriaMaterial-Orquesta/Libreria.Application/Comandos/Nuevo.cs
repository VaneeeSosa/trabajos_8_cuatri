﻿using Libreria.Domain.Interfaces;
using Libreria.Domain.Modelo;
using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace Libreria.Application.Comandos
{
    public class Nuevo
    {
        public class Ejecuta : IRequest<int>
        {
            public string Titulo { get; set; }
            public DateTime? FechaPublicacion { get; set; }
            public string AutorLibro { get; set; }
        }

        public class Manejador : IRequestHandler<Ejecuta, int>
        {
            private readonly ILibreriaMaterialRepositorio _repository;

            public Manejador(ILibreriaMaterialRepositorio repository)
            {
                _repository = repository;
            }

            public async Task<int> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var libro = new LibreriaMaterial
                {
                    Titulo = request.Titulo,
                    FechaPublicacion = request.FechaPublicacion,
                    AutorLibro = request.AutorLibro
                };

                // Guarda el libro en la base de datos.
                await _repository.AddAsync(libro);

                // Asumiendo que el repositorio asigna el ID en libro.LibreriaMaterialId
                var nuevoId = libro.LibreriaMaterialId;

                // RETORNAMOS el ID (no lanzamos excepción aquí).
                return nuevoId;
            }
        }
    }
}

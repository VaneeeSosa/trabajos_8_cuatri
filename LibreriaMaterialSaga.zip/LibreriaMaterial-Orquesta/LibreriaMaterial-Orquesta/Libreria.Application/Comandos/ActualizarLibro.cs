﻿using Libreria.Domain.Interfaces;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Libreria.Application.Comandos
{
    public class ActualizarLibro
    {
        public class Ejecuta : IRequest
        {
            public int LibroId { get; set; }
            public string Titulo { get; set; }
            public DateTime FechaPublicacion { get; set; }
            public string AutorLibro { get; set; }
        }

        public class Manejador : IRequestHandler<Ejecuta>
        {
            private readonly ILibreriaMaterialRepositorio _repository;

            public Manejador(ILibreriaMaterialRepositorio repository)
            {
                _repository = repository;
            }

            public async Task<Unit> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var libro = await _repository.GetByIdAsync(request.LibroId);

                if (libro == null)
                {
                    throw new Exception("No se encontró el libro");
                }

                libro.Titulo = request.Titulo;
                libro.FechaPublicacion = request.FechaPublicacion;
                libro.AutorLibro = request.AutorLibro;

                await _repository.UpdateAsync(libro);

                return Unit.Value;
            }
        }
    }
}
﻿using AutoMapper;
using Libreria.Application.Saga;
using Libreria.Domain.Interfaces;
using MediatR;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Libreria.Application.Comandos
{
    public class Consulta
    {
        public class Ejecuta : IRequest<List<LibreriaMaterialDto>>
        {
        }

        public class Manejador : IRequestHandler<Ejecuta, List<LibreriaMaterialDto>>
        {
            private readonly ILibreriaMaterialRepositorio _repository;
            private readonly IMapper _mapper;
            private readonly IMediator _mediator;

            public Manejador(ILibreriaMaterialRepositorio repository, IMapper mapper, IMediator mediator)
            {
                _repository = repository;
                _mapper = mapper;
                _mediator = mediator;
            }

            public async Task<List<LibreriaMaterialDto>> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var libros = await _repository.GetAllAsync();
                var librosDto = _mapper.Map<List<LibreriaMaterialDto>>(libros);

                // Publica un evento indicando que la consulta se ha completado
                await _mediator.Publish(new ConsultaCompletadaEvent { Libros = librosDto });

                return librosDto;
            }
        }
    }
}
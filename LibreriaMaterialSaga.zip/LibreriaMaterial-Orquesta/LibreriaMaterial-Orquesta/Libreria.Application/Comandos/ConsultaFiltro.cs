﻿using AutoMapper;
using Libreria.Application.Saga;
using Libreria.Domain.Interfaces;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Libreria.Application.Comandos
{
    public class ConsultaFiltro
    {
        public class LibroUnico : IRequest<LibreriaMaterialDto>
        {
            public int LibroId { get; set; }
        }

        public class Manejador : IRequestHandler<LibroUnico, LibreriaMaterialDto>
        {
            private readonly ILibreriaMaterialRepositorio _repository;
            private readonly IMapper _mapper;
            private readonly IMediator _mediator;

            public Manejador(ILibreriaMaterialRepositorio repository, IMapper mapper, IMediator mediator)
            {
                _repository = repository;
                _mapper = mapper;
                _mediator = mediator;
            }

            public async Task<LibreriaMaterialDto> Handle(LibroUnico request, CancellationToken cancellationToken)
            {
                var libro = await _repository.GetByIdAsync(request.LibroId);

                if (libro == null)
                {
                    throw new Exception("No se encontró el libro");
                }

                var libroDto = _mapper.Map<LibreriaMaterialDto>(libro);

                // Publica un evento indicando que la consulta por ID se ha completado
                await _mediator.Publish(new ConsultaPorIdCompletadaEvent { Libro = libroDto });

                return libroDto;
            }
        }
    }
}
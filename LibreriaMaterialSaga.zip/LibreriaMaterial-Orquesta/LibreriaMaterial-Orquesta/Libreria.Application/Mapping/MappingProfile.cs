﻿using AutoMapper;
using Libreria.Domain.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<LibreriaMaterial, LibreriaMaterialDto>()
                .ForMember(dest => dest.LibroMaterialId, opt => opt.MapFrom(src => src.LibreriaMaterialId));
        }
    }
}

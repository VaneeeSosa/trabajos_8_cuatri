﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.Saga
{
    // Evento para representar que se ha completado la consulta por ID
    public class ConsultaPorIdCompletadaEvent : INotification
    {
        public LibreriaMaterialDto Libro { get; set; }
    }

    // Evento para representar que se ha actualizado un libro
    public class LibroActualizadoEvent : INotification
    {
        public int LibroId { get; set; }
        public string Titulo { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string AutorLibro { get; set; }
    }
}

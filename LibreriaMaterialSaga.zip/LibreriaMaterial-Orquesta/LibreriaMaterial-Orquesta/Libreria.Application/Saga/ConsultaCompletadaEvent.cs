﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.Saga
{
    // Evento para representar que se ha completado la consulta
    public class ConsultaCompletadaEvent : INotification
    {
        public List<LibreriaMaterialDto> Libros { get; set; }
    }

    // Evento para representar que se ha creado un libro
    public class LibroCreadoEvent1 : INotification
    {
        public int LibroId { get; set; }
        public string Titulo { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string AutorLibro { get; set; }
    }
}

﻿using Libreria.Application.Comandos;
using Libreria.Application.Saga;
using Libreria.Domain.Interfaces;
using MediatR;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

public class SagaCoordinator
{
    private readonly IMediator _mediator;
    private readonly ILibreriaMaterialRepositorio _repository;
    private readonly SagaState _sagaState;

    public SagaCoordinator(IMediator mediator, ILibreriaMaterialRepositorio repository)
    {
        _mediator = mediator;
        _repository = repository;
        _sagaState = new SagaState();
    }

    public async Task ExecuteSagaAsync(int libroIdParaConsulta)
    {
        try
        {
            // Paso 1: Consultar todos los libros
            var libros = await _mediator.Send(new Consulta.Ejecuta());

            // Paso 2: Crear un nuevo libro basado en los resultados de la consulta
            if (libros.Count > 0)
            {
                // Llamamos a Nuevo.Ejecuta. Ahora sí va a retornar el ID.
                var libroId = await _mediator.Send(new Nuevo.Ejecuta
                {
                    Titulo = "Nuevo Libro Basado en Consulta",
                    FechaPublicacion = DateTime.Now,
                    AutorLibro = "Autor Desconocido"
                });

                // Guardamos el ID en el estado de la Saga
                _sagaState.LibroMaterialId = libroId;

                // FORZAMOS LA EXCEPCIÓN DESPUÉS de recibir el ID
                throw new Exception("Error simulado: Falló en un paso posterior...");

                // -- Este código ya no se ejecuta si lanzas la excepción justo arriba --
                // await _mediator.Publish(new LibroCreadoEvent { ... });
            }

            // Paso 4: Consultar un libro por ID
            var libroConsultado = await _mediator.Send(new ConsultaFiltro.LibroUnico { LibroId = libroIdParaConsulta });

            if (libroConsultado != null)
            {
                // Paso 5: Actualizar el libro encontrado
                await _mediator.Send(new ActualizarLibro.Ejecuta
                {
                    LibroId = libroIdParaConsulta,
                    Titulo = "Título Actualizado",
                    FechaPublicacion = DateTime.Now,
                    AutorLibro = "Autor Actualizado"
                });

                // Paso 6: Publicar el evento de libro actualizado
                await _mediator.Publish(new LibroActualizadoEvent
                {
                    LibroId = libroIdParaConsulta,
                    Titulo = "Título Actualizado",
                    FechaPublicacion = DateTime.Now,
                    AutorLibro = "Autor Actualizado"
                });
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error en la ejecución de la saga: {ex.Message}");
            Debug.WriteLine($"Error en la ejecución de la saga: {ex.Message}");

            // Maneja la compensación en caso de fallo
            await CompensateAsync();
        }
    }

    private async Task CompensateAsync()
    {
        if (_sagaState.LibroMaterialId.HasValue)
        {
            // Elimina el libro creado
            await _repository.DeleteAsync(_sagaState.LibroMaterialId.Value);
            Console.WriteLine($"Libro con ID {_sagaState.LibroMaterialId} eliminado como parte de la compensación.");
            Debug.WriteLine($"Libro con ID {_sagaState.LibroMaterialId} eliminado como parte de la compensación.");
        }
        else
        {
            Console.WriteLine("No hay libro para compensar.");
            Debug.WriteLine("No hay libro para compensar.");
        }
    }
}

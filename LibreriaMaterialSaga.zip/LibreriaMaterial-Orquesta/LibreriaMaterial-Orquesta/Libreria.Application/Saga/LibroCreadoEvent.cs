﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Libreria.Application.Saga
{

    // indica que un libro ha sido creado
    //INotification, es un evento que puede ser manejado por uno o más manejadores de eventos 
    //Guarda el libro en una base de datos.
    public class LibroCreadoEvent : INotification
    {
        public int LibroId { get; set; }
        public string Titulo { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string AutorLibro { get; set; }
    }

    //crear un nuevo libro, Valida los datos del libro, Crea el libro en la base de datos
    //y Publica un evento (LibroCreadoEvent)
    //Este comando se envía (usando IMediator.Send) cuando se desea crear un nuevo libro

    public class CrearLibroCommand
    {
        public string Titulo { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string AutorLibro { get; set; }
    }
}

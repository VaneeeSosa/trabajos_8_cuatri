﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Application.Saga
{
    //esta clase actúa como un contenedor para mantener información sobre los pasos que se han completado
    //en caso de error
    public class SagaState
    {
        public int? LibroMaterialId { get; set; } // Almacena el ID del libro creado
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Libreria.Application.Comandos;
using MediatR;
using System.Collections.Generic;
using System.Threading.Tasks;
using Libreria.Application;

namespace Microservicio.LibreriaMaterial.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibreriaMaterialController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly SagaCoordinator _sagaCoordinator;


        public LibreriaMaterialController(IMediator mediator, SagaCoordinator sagaCoordinator)
        {
            _mediator = mediator;
            _sagaCoordinator = sagaCoordinator;
        }

        // POST api/<ValuesController>
        [HttpPost]
        public async Task<ActionResult<Unit>> Crear(Nuevo.Ejecuta data)
        {
            var result = await _mediator.Send(data);
            return Ok(result); 
        }

        [HttpGet]
        public async Task<ActionResult<List<LibreriaMaterialDto>>> GetLibros()
        {
            var libros = await _mediator.Send(new Consulta.Ejecuta());
            return Ok(libros); 
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LibreriaMaterialDto>> GetLibroUnico(int id)
        {
            var libro = await _mediator.Send(new ConsultaFiltro.LibroUnico
            {
                LibroId = id
            });

            if (libro == null)
            {
                return NotFound(); 
            }

            return Ok(libro); 
        }

        [HttpPost("start-saga/{id}")]
        public async Task<IActionResult> StartSaga(int id)
        {
            try
            {
                // Invoca la saga con el ID a consultar
                await _sagaCoordinator.ExecuteSagaAsync(id);

                return Ok("Saga ejecutada con éxito");
            }
            catch (Exception ex)
            {
                // Manejar el error si hace falta
                return StatusCode(500, ex.Message);
            }
        }

    }
}
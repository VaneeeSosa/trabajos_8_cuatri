﻿using System.ComponentModel.DataAnnotations;

namespace MongoAplicacion.Models
{
    public class BackupManagementViewModel
    {
        [Required(ErrorMessage = "El nombre de la base de datos es requerido.")]
        public string DatabaseName { get; set; }

        [Required(ErrorMessage = "El tipo de backup es requerido.")]
        public string BackupType { get; set; }

        public IEnumerable<BackupFile> BackupFiles { get; set; }
    }
}

﻿namespace MongoAplicacion.Models
{
    public class BackupFile
    {
        public string FileName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string BackupType { get; set; }
    }
}

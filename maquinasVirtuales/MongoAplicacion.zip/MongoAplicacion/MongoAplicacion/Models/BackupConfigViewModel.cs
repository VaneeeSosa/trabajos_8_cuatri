﻿using System.ComponentModel.DataAnnotations;

namespace MongoAplicacion.Models
{
    public class BackupConfigViewModel
    {
        [Required(ErrorMessage = "La ruta base es requerida.")]
        [Display(Name = "Ruta Base de Almacenamiento")]
        public string BaseBackupPath { get; set; }
    }
}

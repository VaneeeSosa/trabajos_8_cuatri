﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Bson.Serialization;
using MongoAplicacion.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace MongoAplicacion.Controllers
{
    public class BackupController : Controller
    {
        private readonly MongoDBSettings _mongoSettings;
        private readonly IMongoDatabase _database;

        public BackupController(IOptions<MongoDBSettings> mongoSettings)
        {
            _mongoSettings = mongoSettings.Value;
            var client = new MongoClient(_mongoSettings.ConnectionString);
            _database = client.GetDatabase(_mongoSettings.DatabaseName);
        }

        public IActionResult Index()
        {
            var collections = _database.ListCollectionNames().ToList();
            return View(collections);
        }

        [HttpPost]
        public IActionResult CreateCollection(string collectionName, string jsonData)
        {
            try
            {
                if (string.IsNullOrEmpty(collectionName))
                {
                    TempData["Error"] = "El nombre de la colección no puede estar vacío.";
                    return RedirectToAction("Index");
                }

                _database.CreateCollection(collectionName);

                if (!string.IsNullOrEmpty(jsonData))
                {
                    var collection = _database.GetCollection<BsonDocument>(collectionName);
                    if (jsonData.Trim().StartsWith("["))
                    {
                        var documents = BsonSerializer.Deserialize<List<BsonDocument>>(jsonData);
                        collection.InsertMany(documents);
                    }
                    else
                    {
                        var document = BsonSerializer.Deserialize<BsonDocument>(jsonData);
                        collection.InsertOne(document);
                    }
                }

                TempData["Success"] = "Colección creada exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al crear la colección: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult ExportCollection(string collectionName)
        {
            try
            {
                var collection = _database.GetCollection<BsonDocument>(collectionName);
                var documents = collection.Find(new BsonDocument()).ToList();

                if (documents.Count == 0)
                {
                    TempData["Error"] = "No hay datos para exportar.";
                    return RedirectToAction("Index");
                }

                var json = JsonConvert.SerializeObject(documents, Formatting.Indented);
                var filePath = Path.Combine("C:\\Exports", collectionName + ".json");
                System.IO.File.WriteAllText(filePath, json);

                TempData["Success"] = "Exportación realizada con éxito.";
                return File(System.IO.File.ReadAllBytes(filePath), "application/json", collectionName + ".json");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al exportar la colección: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult ImportCollection(string collectionName, IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    TempData["Error"] = "Debe seleccionar un archivo para importar.";
                    return RedirectToAction("Index");
                }

                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    var jsonData = reader.ReadToEnd();
                    var collection = _database.GetCollection<BsonDocument>(collectionName);

                    if (jsonData.Trim().StartsWith("["))
                    {
                        var documents = BsonSerializer.Deserialize<List<BsonDocument>>(jsonData);
                        collection.InsertMany(documents);
                    }
                    else
                    {
                        var document = BsonSerializer.Deserialize<BsonDocument>(jsonData);
                        collection.InsertOne(document);
                    }
                }

                TempData["Success"] = "Importación completada con éxito.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al importar los datos: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult CreateRole(string roleName)
        {
            try
            {
                if (string.IsNullOrEmpty(roleName))
                {
                    TempData["Error"] = "El nombre del rol no puede estar vacío.";
                    return RedirectToAction("Index");
                }

                var rolesCollection = _database.GetCollection<BsonDocument>("roles");
                var role = new BsonDocument { { "RoleName", roleName } };
                rolesCollection.InsertOne(role);

                TempData["Success"] = "Rol creado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al crear el rol: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult AssignRole(string userName, string roleName)
        {
            try
            {
                if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(roleName))
                {
                    TempData["Error"] = "El usuario y el rol no pueden estar vacíos.";
                    return RedirectToAction("Index");
                }

                var usersCollection = _database.GetCollection<BsonDocument>("users");
                var filter = Builders<BsonDocument>.Filter.Eq("UserName", userName);
                var update = Builders<BsonDocument>.Update.Set("Role", roleName);
                usersCollection.UpdateOne(filter, update);

                TempData["Success"] = "Rol asignado correctamente.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al asignar el rol: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult GetRoles()
        {
            try
            {
                var rolesCollection = _database.GetCollection<BsonDocument>("roles");
                var roles = rolesCollection.Find(new BsonDocument()).ToList();
                return Json(roles);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = $"Error al obtener roles: {ex.Message}" });
            }
        }
    }
}

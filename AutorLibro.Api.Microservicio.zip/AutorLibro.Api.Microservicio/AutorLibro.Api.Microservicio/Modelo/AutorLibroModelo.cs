﻿using System.ComponentModel.DataAnnotations;

namespace AutorLibro.Api.Microservicio.Modelo
{
    public class AutorLibroModelo
    {
        [Key]
        public int AutorLibroId { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string AutorLibroGuid { get; set; }


        public ICollection<GradoAcademico> GradoAcademico { get; set; }

    }


}

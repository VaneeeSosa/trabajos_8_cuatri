﻿using AutorLibro.Api.Microservicio.Modelo;
using System.ComponentModel.DataAnnotations;

public class GradoAcademico
{
    [Key]
    public int GradoAcademicoId { get; set; }
    public string Nombre { get; set; }
    public string CentroAcademico { get; set; }
    public DateTime FechaGrado { get; set; }
    public string GradoAcademicoGuid { get; set; }

    public int AutorLibroId { get; set; }
    public AutorLibroModelo AutorLibro { get; set; }
}
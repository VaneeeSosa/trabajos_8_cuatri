﻿using Microsoft.EntityFrameworkCore;
using AutorLibro.Api.Microservicio.Modelo; 

namespace AutorLibro.Api.Microservicio.Persistencia
{
    public class AutorLibrosContext : DbContext
    {
        public AutorLibrosContext(DbContextOptions<AutorLibrosContext> options) : base(options)
        {
        
        }



        public DbSet<Modelo.AutorLibroModelo> AutorLibros { get; set; }
        public DbSet<GradoAcademico> GradoAcademico { get; set; }
    }
}

﻿using AutorLibro.Api.Microservicio.Modelo;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class GradoAcademicoDto
    {
        public int GradoAcademicoId { get; set; }
        public string Nombre { get; set; }
        public string CentroAcademico { get; set; }
        public DateTime FechaGrado { get; set; }
        public Modelo.AutorLibroModelo AutorLibro { get; set; }
        public string GradoAcademicoGuid { get; set; }
    }
}

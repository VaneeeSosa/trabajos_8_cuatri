﻿using AutorLibro.Api.Microservicio.Modelo;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class AutorLibroDto
    {
        public int AutorLibroId { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public ICollection<GradoAcademico> GradoAcademico { get; set; }
        public string AutorLibroGuid { get; set; }
    }
}

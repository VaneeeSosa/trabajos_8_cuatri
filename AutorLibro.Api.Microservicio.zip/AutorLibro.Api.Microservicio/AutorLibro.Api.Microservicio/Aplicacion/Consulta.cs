﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using AutorLibro.Api.Microservicio.Modelo;
using AutorLibro.Api.Microservicio.Persistencia;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class Consulta
    {
        public class Ejecuta : IRequest<List<AutorLibroDto>> 
        { 
        
           public Ejecuta()
            {

            }

        }

        public class Manejador : IRequestHandler<Ejecuta, List<AutorLibroDto>>
        {
            private readonly AutorLibrosContext _context;
            private readonly IMapper _mapper;

            public Manejador(AutorLibrosContext context, IMapper mapper)
            {
                _context = context;
                _mapper = mapper;
            }

            public async Task<List<AutorLibroDto>> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var autores = await _context.AutorLibros
                    .Include(a => a.GradoAcademico)
                    .ToListAsync();




                var autoresdto = _mapper.Map<List<AutorLibroModelo>, List<AutorLibroDto>>(autores);


                return autoresdto;
            }
        }
    }
}

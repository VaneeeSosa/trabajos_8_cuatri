﻿using AutoMapper;
using AutorLibro.Api.Microservicio.Modelo;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class MappingProfile : Profile
    {
       public MappingProfile()
        {
            CreateMap<AutorLibroModelo, AutorLibroDto>();
            CreateMap<GradoAcademico, GradoAcademicoDto>();
        }
    }
}

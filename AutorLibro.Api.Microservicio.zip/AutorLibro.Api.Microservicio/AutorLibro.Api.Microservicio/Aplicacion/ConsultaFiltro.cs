﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using AutorLibro.Api.Microservicio.Modelo;
using AutorLibro.Api.Microservicio.Persistencia;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class ConsultaFiltro
    {
        public class Ejecuta : IRequest<AutorLibroDto>
        {
            public int AutorLibroId { get; set; }
        }

        public class Manejador : IRequestHandler<Ejecuta, AutorLibroDto>
        {
            private readonly AutorLibrosContext _context;
            private readonly IMapper _mapper;

            public Manejador(AutorLibrosContext context, IMapper mapper)
            {
                _context = context;
                _mapper = mapper;
            }

            public async Task<AutorLibroDto> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var autor = await _context.AutorLibros
                    .Include(a => a.GradoAcademico)
                    .FirstOrDefaultAsync(a => a.AutorLibroId == request.AutorLibroId, cancellationToken);

                if (autor == null)
                {
                    throw new Exception("El autor no existe");
                }

                return _mapper.Map<AutorLibroDto>(autor);
            }
        }
    }
}

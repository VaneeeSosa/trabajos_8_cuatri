﻿using FluentValidation;
using MediatR;
using AutorLibro.Api.Microservicio.Modelo;
using AutorLibro.Api.Microservicio.Persistencia;
using System.Linq;

namespace AutorLibro.Api.Microservicio.Aplicacion
{
    public class Nuevo
    {
       
        public class Ejecuta : IRequest<Unit>
        {
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public DateTime FechaNacimiento { get; set; }
            public string AutorLibroGuid { get; set; }
            public List<GradoAcademicoData> GradoAcademico { get; set; }
        }

        public class GradoAcademicoData
        {
            public string Nombre { get; set; }
            public string CentroAcademico { get; set; }
            public DateTime FechaGrado { get; set; }
            public string GradoAcademicoGuid { get; set; }
        }

        public class EjecutaValidacion : AbstractValidator<Ejecuta>
        {
            public EjecutaValidacion()
            {
                RuleFor(x => x.Nombre).NotEmpty();
                RuleFor(x => x.Apellido).NotEmpty();
                RuleFor(x => x.FechaNacimiento).NotEmpty();
                RuleFor(x => x.AutorLibroGuid).NotEmpty();
                RuleFor(x => x.GradoAcademico).NotNull();
            }
        }

        public class Manejador : IRequestHandler<Ejecuta, Unit>
        {
            private readonly AutorLibrosContext _context;

            public Manejador(AutorLibrosContext context)
            {
                _context = context;
            }

            public async Task<Unit> Handle(Ejecuta request, CancellationToken cancellationToken)
            {
                var autor = new Modelo.AutorLibroModelo
                {
                    Nombre = request.Nombre,
                    Apellido = request.Apellido,
                    FechaNacimiento = request.FechaNacimiento,
                    AutorLibroGuid = request.AutorLibroGuid,
                    GradoAcademico = request.GradoAcademico?.Select(g => new GradoAcademico
                    {
                        Nombre = g.Nombre,
                        CentroAcademico = g.CentroAcademico,
                        FechaGrado = g.FechaGrado,
                        GradoAcademicoGuid = g.GradoAcademicoGuid
                    }).ToList()};

                _context.AutorLibros.Add(autor);
                var result = await _context.SaveChangesAsync(cancellationToken);
                if (result > 0)
                {
                    return Unit.Value;
                }
                throw new Exception("No se pudo insertar el autor y sus grados académicos");
            }
        }

    }
}

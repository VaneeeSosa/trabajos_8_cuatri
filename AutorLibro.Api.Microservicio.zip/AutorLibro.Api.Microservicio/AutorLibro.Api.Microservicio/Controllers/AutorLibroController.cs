﻿using AutorLibro.Api.Microservicio.Aplicacion;
using MediatR;
using Microsoft.AspNetCore.Mvc;


namespace AutorLibro.Api.Microservicio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutorLibroController : ControllerBase
    {
        private readonly IMediator _mediator;
        public AutorLibroController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<AutorLibroDto>>> Get()
        {
            return await _mediator.Send(new Consulta.Ejecuta());
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<AutorLibroDto>> Get(int id)
        {
            return await _mediator.Send(new ConsultaFiltro.Ejecuta { AutorLibroId = id });
        }

        [HttpPost]
        public async Task<ActionResult<Unit>> crearAutor(Nuevo.Ejecuta data)
        {
            return await _mediator.Send(data);
        }


    }
}

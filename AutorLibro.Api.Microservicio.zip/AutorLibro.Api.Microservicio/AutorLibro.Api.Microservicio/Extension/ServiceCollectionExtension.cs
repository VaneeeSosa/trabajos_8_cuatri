﻿using FluentValidation.AspNetCore;
using MediatR;
using AutorLibro.Api.Microservicio.Aplicacion;
using AutorLibro.Api.Microservicio.Persistencia;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;


namespace AutorLibro.Api.Microservicio.Extension;
public static class ServiceCollectionExtension
{
    public static IServiceCollection AddCustomServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddControllers().AddFluentValidation(cfg => cfg.RegisterValidatorsFromAssemblyContaining<Nuevo>());

        services.AddDbContext<AutorLibrosContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"))); // Asegúrate de tener la referencia a Microsoft.EntityFrameworkCore.SqlServer

        services.AddCors(options =>
        {
            options.AddPolicy("AllowAll", builder =>
            {
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            });
        });

        services.AddMediatR(typeof(Nuevo.Manejador).Assembly);
        services.AddAutoMapper(typeof(Consulta.Manejador));

        return services;
    }
}

